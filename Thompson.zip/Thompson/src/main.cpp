#include "Aplicacion.hpp"

int main(int argc, char *argv[]){
	Aplicacion a;
	a.iniciar(argc,argv);
	return 0;
}
