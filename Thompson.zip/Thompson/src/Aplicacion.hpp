#ifndef __APLICACION_HPP__
#define __APLICACION_HPP__

#include "Convertidor.hpp"

class Aplicacion{
	private:
		Convertidor conver;
	public:
		void iniciar(int,char *[]);
};

#endif
